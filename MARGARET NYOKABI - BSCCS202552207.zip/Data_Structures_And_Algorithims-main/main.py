# ===== Primitive Data Structures =====
# Integer
integer_example = 10

# Float
float_example = 3.14

# Character
char_example = 'A'

# Boolean
boolean_example = True

# Print all examples
print("Integer:", integer_example)
print("Float:", float_example)
print("Character:", char_example)
print("Boolean:", boolean_example)

# ===== Linear Data Structures: Array (List) =====
numbers = [10, 20, 30, 40]

# Accessing elements
print("\nArray/List Example:")
print("First element:", numbers[0])
print("All elements:", numbers)

# ===== Linear Data Structures: Stack (LIFO) =====
stack = []

# Pushing elements onto stack
stack.append(10)
stack.append(20)
stack.append(30)

print("\nStack Example (LIFO):")
print("Stack before popping:", stack)

# Popping the last element
popped_element = stack.pop()
print("Popped element:", popped_element)
print("Stack after popping:", stack)

# ===== Linear Data Structures: Queue (FIFO) =====
from collections import deque

queue = deque()

# Enqueue elements
queue.append(10)
queue.append(20)
queue.append(30)

print("\nQueue Example (FIFO):")
print("Queue before dequeue:", list(queue))

# Dequeue the first element
dequeued_element = queue.popleft()
print("Dequeued element:", dequeued_element)
print("Queue after dequeue:", list(queue))

# ===== Linear Data Structures: Linked List =====

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    # Insert at the beginning
    def insert(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    # Print linked list
    def print_list(self):
        current = self.head
        elements = []
        while current:
            elements.append(current.data)
            current = current.next
        print("Linked List:", elements)

# Create linked list and add elements
ll = LinkedList()
ll.insert(10)
ll.insert(20)
ll.insert(30)

ll.print_list()

# ===== Non-Linear Data Structures: Tree (Binary Tree) =====

class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

# Create a simple tree
root = TreeNode(10)
root.left = TreeNode(5)
root.right = TreeNode(15)

# Simple function to print tree in-order
def inorder_traversal(node):
    if node:
        inorder_traversal(node.left)
        print(node.value, end=" ")
        inorder_traversal(node.right)

print("\nBinary Tree (In-order Traversal):")
inorder_traversal(root)
print()

# ===== Non-Linear Data Structures: Graph =====

graph = {
    "A": ["B", "C"],
    "B": ["A", "D"],
    "C": ["A"],
    "D": ["B"]
}

print("\nGraph Example:")
for node, edges in graph.items():
    print(f"{node} -> {edges}")

# ===== Non-Linear Data Structures: Hash Table (Dictionary) =====

hash_table = {
    "name": "Margaret",
    "age": 19,
    "city": "Thika"
}

print("\nHash Table Example:")
for key, value in hash_table.items():
    print(f"{key} : {value}")
