# DATA STRUCTURES ASSIGNMENT
# Classification and Examples in Python

print("=" * 60)
print("DATA STRUCTURES CLASSIFICATION AND EXAMPLES")
print("=" * 60)

# ============================================
# PART 1: PRIMITIVE DATA TYPES
# ============================================
print("\n1️⃣  PRIMITIVE DATA TYPES")
print("-" * 40)

# Integer
age = 25
print(f"Integer: {age} - Type: {type(age)}")

# Float
price = 19.99
print(f"Float: {price} - Type: {type(price)}")

# String
name = "Alice"
print(f"String: '{name}' - Type: {type(name)}")

# Boolean
is_student = True
print(f"Boolean: {is_student} - Type: {type(is_student)}")

print("\n✅ Primitive types are the basic building blocks of data in Python.")


# ============================================
# PART 2: ARRAY (Static & Dynamic Linear)
# ============================================
print("\n2️⃣  ARRAYS (Static & Dynamic Linear)")
print("-" * 40)

# Static array using tuple (cannot change)
static_array = (10, 20, 30, 40, 50)
print(f"Static tuple (fixed size): {static_array}")
print(f"Access element at index 2: {static_array[2]}")

# Dynamic array using list (can change)
dynamic_array = [10, 20, 30, 40, 50]
print(f"Dynamic list (can grow): {dynamic_array}")

# List operations
dynamic_array.append(60)
print(f"After append(60): {dynamic_array}")
dynamic_array.insert(2, 25)
print(f"After insert at index 2: {dynamic_array}")
dynamic_array.remove(30)
print(f"After remove(30): {dynamic_array}")
popped = dynamic_array.pop()
print(f"After pop(): {dynamic_array} (removed {popped})")

print("\n✅ Arrays store elements in contiguous memory. Access by index is O(1).")


# ============================================
# PART 3: LINKED LIST (Dynamic Linear)
# ============================================
print("\n3️⃣  LINKED LIST (Dynamic Linear)")
print("-" * 40)

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
    
    def insert(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node
        print(f"  Inserted: {data}")
    
    def display(self):
        if not self.head:
            print("  List is empty")
            return
        elements = []
        current = self.head
        while current:
            elements.append(str(current.data))
            current = current.next
        print("  Linked List: " + " → ".join(elements))

# Create and use linked list
ll = LinkedList()
ll.insert(10)
ll.insert(20)
ll.insert(30)
ll.insert(40)
ll.display()

print("\n✅ Each node has data and pointer to next node. Insertion/deletion is easy.")


# ============================================
# PART 4: STACK (LIFO - Last In First Out)
# ============================================
print("\n4️⃣  STACK (LIFO - Last In First Out)")
print("-" * 40)

class Stack:
    def __init__(self):
        self.items = []
    
    def push(self, item):
        self.items.append(item)
        print(f"  Push: {item}")
    
    def pop(self):
        if not self.is_empty():
            item = self.items.pop()
            print(f"  Pop: {item}")
            return item
        print("  Stack is empty")
        return None
    
    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        return None
    
    def is_empty(self):
        return len(self.items) == 0
    
    def display(self):
        print(f"  Stack (top → bottom): {self.items[::-1]}")

# Demonstrate stack
stack = Stack()
stack.push(10)
stack.push(20)
stack.push(30)
stack.display()
stack.pop()
stack.pop()
print(f"  Top element: {stack.peek()}")
stack.display()

print("\n✅ Stack follows LIFO - used in undo operations, function calls.")


# ============================================
# PART 5: QUEUE (FIFO - First In First Out)
# ============================================
print("\n5️⃣  QUEUE (FIFO - First In First Out)")
print("-" * 40)
from collections import deque

class Queue:
    def __init__(self):
        self.items = deque()
    
    def enqueue(self, item):
        self.items.append(item)
        print(f"  Enqueue: {item}")
    
    def dequeue(self):
        if not self.is_empty():
            item = self.items.popleft()
            print(f"  Dequeue: {item}")
            return item
        print("  Queue is empty")
        return None
    
    def front(self):
        if not self.is_empty():
            return self.items[0]
        return None
    
    def is_empty(self):
        return len(self.items) == 0
    
    def display(self):
        print(f"  Queue (front ← ← rear): {list(self.items)}")

# Demonstrate queue
queue = Queue()
queue.enqueue(10)
queue.enqueue(20)
queue.enqueue(30)
queue.display()
queue.dequeue()
queue.dequeue()
print(f"  Front element: {queue.front()}")
queue.display()

print("\n✅ Queue follows FIFO - used in printing, scheduling, BFS.")


# ============================================
# PART 6: TREE (Non-Linear Hierarchical)
# ============================================
print("\n6️⃣  TREE (Non-Linear Hierarchical)")
print("-" * 40)

class TreeNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

class BinaryTree:
    def __init__(self):
        self.root = None
    
    def inorder(self, node):
        """Left → Root → Right traversal"""
        if node:
            self.inorder(node.left)
            print(node.data, end=" ")
            self.inorder(node.right)

# Create a binary tree
tree = BinaryTree()
tree.root = TreeNode(10)
tree.root.left = TreeNode(5)
tree.root.right = TreeNode(15)
tree.root.left.left = TreeNode(3)
tree.root.left.right = TreeNode(7)
tree.root.right.right = TreeNode(20)

print("Tree structure:")
print("      10")
print("     /  \\")
print("    5    15")
print("   / \\     \\")
print("  3   7     20")

print("\nIn-order traversal (sorted): ", end="")
tree.inorder(tree.root)

print("\n\n✅ Tree has parent-child relationships - used in file systems, HTML DOM.")


# ============================================
# PART 7: GRAPH (Non-Linear Network)
# ============================================
print("\n7️⃣  GRAPH (Non-Linear Network)")
print("-" * 40)
from collections import defaultdict, deque

class Graph:
    def __init__(self):
        self.graph = defaultdict(list)
    
    def add_edge(self, u, v):
        self.graph[u].append(v)
        self.graph[v].append(u)
        print(f"  Added edge: {u} -- {v}")
    
    def display(self):
        for node in sorted(self.graph.keys()):
            print(f"  {node} → {sorted(self.graph[node])}")
    
    def bfs(self, start):
        visited = set()
        queue = deque([start])
        visited.add(start)
        
        result = []
        while queue:
            node = queue.popleft()
            result.append(node)
            
            for neighbor in sorted(self.graph[node]):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        
        print(f"  BFS from {start}: {' → '.join(result)}")

# Create a simple social network graph
g = Graph()
g.add_edge('Alice', 'Bob')
g.add_edge('Alice', 'Charlie')
g.add_edge('Bob', 'David')
g.add_edge('Charlie', 'David')
g.add_edge('David', 'Eve')

print("\nGraph adjacency list:")
g.display()
g.bfs('Alice')

print("\n✅ Graph has vertices connected by edges - used in social networks, maps.")


# ============================================
# PART 8: HASH TABLE (Dictionary)
# ============================================
print("\n8️⃣  HASH TABLE (Dictionary)")
print("-" * 40)

# Python dictionary is a hash table
student_grades = {
    "Alice": 85,
    "Bob": 92,
    "Charlie": 78,
    "David": 88
}

print(f"Student grades: {student_grades}")
print(f"Alice's grade: {student_grades['Alice']}")

# Operations
student_grades["Eve"] = 95
print(f"After adding Eve: {student_grades}")
del student_grades["Charlie"]
print(f"After removing Charlie: {student_grades}")

print("\n✅ Hash tables use key-value pairs with O(1) average access time.")


# ============================================
# SUMMARY TABLE
# ============================================
print("\n" + "=" * 60)
print("SUMMARY - DATA STRUCTURES CLASSIFICATION")
print("=" * 60)
print("""
| Data Structure | Category        | Access | Search | Insert | Delete | Python Used     |
|----------------|-----------------|--------|--------|--------|--------|-----------------|
| Array          | Static Linear   | O(1)   | O(n)   | O(n)   | O(n)   | tuple/list      |
| Linked List    | Dynamic Linear  | O(n)   | O(n)   | O(1)   | O(1)   | Node class      |
| Stack          | Dynamic Linear  | O(n)   | O(n)   | O(1)   | O(1)   | list            |
| Queue          | Dynamic Linear  | O(n)   | O(n)   | O(1)   | O(1)   | deque           |
| Tree           | Non-Linear      | O(log n)| O(log n)| O(log n)| O(log n)| TreeNode class |
| Graph          | Non-Linear      | O(1)   | O(V+E) | O(1)   | O(1)   | defaultdict     |
| Hash Table     | Linear          | O(1)   | O(1)   | O(1)   | O(1)   | dict            |
""")

print("\n" + "=" * 60)
print("✅ ASSIGNMENT COMPLETE - ALL DATA STRUCTURES COVERED")
print("=" * 60)
