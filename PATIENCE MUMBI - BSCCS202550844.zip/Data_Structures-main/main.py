integer_example = 10


float_example = 3.14


char_example = 'A'


boolean_example = True


print("Integer:", integer_example)
print("Float:", float_example)
print("Character:", char_example)
print("Boolean:", boolean_example)


numbers = [10, 20, 30, 40]


print("\nArray/List Example:")
print("First element:", numbers[0])
print("All elements:", numbers)


stack = []


stack.append(20)
stack.append(30)

print("\nStack Example (LIFO):")
print("Stack before popping:", stack)


popped_element = stack.pop()
print("Popped element:", popped_element)
print("Stack after popping:", stack)


from collections import deque

queue = deque()


queue.append(10)
queue.append(20)
queue.append(30)

print("\nQueue Example (FIFO):")
print("Queue before dequeue:", list(queue))


dequeued_element = queue.popleft()
print("Dequeued element:", dequeued_element)
print("Queue after dequeue:", list(queue))



class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None


    def insert(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

   
    def print_list(self):
        current = self.head
        elements = []
        while current:
            elements.append(current.data)
            current = current.next
        print("Linked List:", elements)


ll = LinkedList()
ll.insert(10)
ll.insert(20)
ll.insert(30)

ll.print_list()



class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


root = TreeNode(10)
root.left = TreeNode(5)
root.right = TreeNode(15)


def inorder_traversal(node):
    if node:
        inorder_traversal(node.left)
        print(node.value, end=" ")
        inorder_traversal(node.right)

print("\nBinary Tree (In-order Traversal):")
inorder_traversal(root)
print()



graph = {
    "A": ["B", "C"],
    "B": ["A", "D"],
    "C": ["A"],
    "D": ["B"]
}

print("\nGraph Example:")
for node, edges in graph.items():
    print(f"{node} -> {edges}")


hash_table = {
    "name": "Peshy",
    "age": 19,
    "city": "Thika"
}

print("\nHash Table Example:")
for key, value in hash_table.items():
    print(f"{key} : {value}")
